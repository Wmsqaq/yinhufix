﻿# YinHuFix GUI @NovaPupil_  v1.7.20261025
# PowerShell WinForms 界面壳: 复用各功能模块(YINFU_AUTO=1 自动确认), 实时日志, 更新横幅
# 要求: Windows 10 1903+ / PowerShell 5.1(系统内置) / 管理员权限(自动提权)
$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing
[Windows.Forms.Application]::EnableVisualStyles()
[Console]::OutputEncoding = [Text.Encoding]::GetEncoding(936)

$ToolDir = Split-Path -Parent $MyInvocation.MyCommand.Path

# ---- 管理员自检与自提权 ----
$wi = [Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()
if (-not $wi.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) {
    Start-Process -FilePath 'powershell.exe' -Verb RunAs -ArgumentList @(
        '-NoProfile', '-ExecutionPolicy', 'Bypass', '-WindowStyle', 'Hidden',
        '-File', ('"{0}"' -f $PSCommandPath)
    )
    exit 0
}

# ---- 读取本地版本(主程序 TOOLVER) ----
$Ver = '0'
$mainBat = Get-ChildItem -LiteralPath $ToolDir -Filter 'YinHuFix_*.bat' |
    Where-Object { $_.Name -notmatch 'AVInstall|FixUpdate|UnblockAV|KillVariant|SelfUpdate|HostsClean|WDAC|ScanHide|SysReg' } |
    Select-Object -First 1
if ($mainBat) {
    $tl = Select-String -LiteralPath $mainBat.FullName -Pattern '^REM TOOLVER=(.+)$' |
        Select-Object -First 1
    if ($tl) { $Ver = $tl.Matches[0].Groups[1].Value.Trim() }
}

# ---- 功能定义 ----
$Features = @(
    @{ Key='1'; Name='修复 WDAC 应用控制拦截'; Bat='YinHuFix_WDAC.bat';      Arg='MAIN';
       Desc="清掉可疑的 WDAC 策略文件，恢复被改的系统限制项。`n有改动会提示重启（工具不会替你重启）。" }
    @{ Key='2'; Name='解禁杀毒软件(影响大)';   Bat='YinHuFix_UnblockAV.bat'; Arg='MAIN';
       Desc="解禁被病毒压制的杀毒软件：清策略、劫持隐藏进程、禁高置信可疑服务。`nSangfor 服务会跳过（处理了会断 VPN）。`n只在确认中招、杀软打不开的机器上用。" }
    @{ Key='3'; Name='深度扫描(只读报告)';     Bat='YinHuFix_ScanHide.bat';  Arg='MAIN';
       Desc="扫描隐藏进程、启动项、计划任务、Public 释放物、Defender 状态和 C2 回连。`n只查不动。" }
    @{ Key='4'; Name='恢复 Windows 更新';      Bat='YinHuFix_FixUpdate.bat'; Arg='MAIN';
       Desc="恢复被禁用的更新服务，只清真正阻断更新的策略值。`n主动暂停的更新会保留。" }
    @{ Key='5'; Name='清除系统限制注册表';     Bat='YinHuFix_SysReg.bat';    Arg='MAIN';
       Desc="恢复任务管理器、注册表、CMD、运行框、UAC、Defender 这些被禁的系统功能。" }
    @{ Key='6'; Name='获取杀毒软件安装包';     Bat='YinHuFix_AVInstall.bat'; Arg='';
       Desc="列出常用杀软，本地有安装包就直接用，没有就下载。`n列表里有云端下发的条目。" }
    @{ Key='7'; Name='新变种专项清理';         Bat='YinHuFix_KillVariant.bat'; Arg='MAIN';
       Desc="针对门控投递器新变种：IOC 任务、Public 释放物、伪装更新包、Defender 致盲、C2 回连。`n确认后一键处置。" }
    @{ Key='8'; Name='检查更新';               Bat='YinHuFix_SelfUpdate.bat'; Arg='MAIN';
       Desc="检查新版本。Gitee 连不上自动换 GitHub，下载前先校验 SHA-256。" }
    @{ Key='9'; Name='一键清空 hosts 配置';    Bat='YinHuFix_HostsClean.bat'; Arg='MAIN';
       Desc="hosts 被改得乱七八糟时用：先备份到 hosts_backup，再恢复系统默认，顺带刷新 DNS 缓存。" }
)

# ---- 主窗体 ----
$form = New-Object Windows.Forms.Form
$form.Text = "银狐病毒综合修复工具 GUI v$Ver @NovaPupil_"
$form.Size = New-Object Drawing.Size(1020, 700)
$form.StartPosition = 'CenterScreen'
$form.FormBorderStyle = 'FixedSingle'
$form.MaximizeBox = $false
$form.Font = New-Object Drawing.Font('微软雅黑', 9)
$form.BackColor = [Drawing.Color]::FromArgb(24, 30, 46)

$lblVer = New-Object Windows.Forms.Label
$lblVer.Text = "本地版本 v$Ver　·　处置都会先经你确认，日志实时显示"
$lblVer.ForeColor = [Drawing.Color]::FromArgb(143,160,192)
$lblVer.Location = New-Object Drawing.Point(18, 12)
$lblVer.AutoSize = $true
$form.Controls.Add($lblVer)

$lblUpd = New-Object Windows.Forms.Label
$lblUpd.Text = '更新状态：检测中…'
$lblUpd.ForeColor = [Drawing.Color]::FromArgb(143,160,192)
$lblUpd.Location = New-Object Drawing.Point(700, 12)
$lblUpd.AutoSize = $true
$form.Controls.Add($lblUpd)

# ---- 功能按钮区 ----
$btnPanel = New-Object Windows.Forms.Panel
$btnPanel.Location = New-Object Drawing.Point(14, 40)
$btnPanel.Size = New-Object Drawing.Size(300, 560)
$form.Controls.Add($btnPanel)

$tip = New-Object Windows.Forms.ToolTip
$tip.AutoPopDelay = 8000; $tip.InitialDelay = 300
$script:btns = @{}
$y = 4
foreach ($f in $Features) {
    $b = New-Object Windows.Forms.Button
    $b.Text = "[$($f.Key)] $($f.Name)"
    $b.Tag = $f
    $b.Size = New-Object Drawing.Size(288, 44)
    $b.Location = New-Object Drawing.Point(4, $y)
    $b.FlatStyle = 'Flat'
    $b.BackColor = [Drawing.Color]::FromArgb(29,38,56)
    $b.ForeColor = [Drawing.Color]::FromArgb(219,228,245)
    $b.TextAlign = 'MiddleLeft'
    $b.Padding = New-Object Windows.Forms.Padding(8, 0, 0, 0)
    $b.Add_Click({ GUI-RunFeature $this.Tag })
    $tip.SetToolTip($b, $f.Desc)
    $btnPanel.Controls.Add($b)
    $script:btns[$f.Key] = $b
    $y += 50
}

# ---- 日志区 ----
$log = New-Object Windows.Forms.RichTextBox
$log.Location = New-Object Drawing.Point(324, 40)
$log.Size = New-Object Drawing.Size(668, 560)
$log.ReadOnly = $true
$log.BackColor = [Drawing.Color]::FromArgb(12,17,29)
$log.ForeColor = [Drawing.Color]::FromArgb(184,216,255)
$log.Font = New-Object Drawing.Font('Consolas', 9)
$log.DetectUrls = $false
$form.Controls.Add($log)

function Write-Log([string]$text, $color) {
    if ($form.IsDisposed -or -not $log.IsHandleCreated) { return }
    $log.SelectionStart = $log.TextLength
    $log.SelectionLength = 0
    $log.SelectionColor = $color
    foreach ($line in ($text -split "`r?`n")) {
        $log.AppendText(($line -replace "\x1b\[[0-9;]*m", '') + "`n")
    }
    $log.SelectionColor = $log.ForeColor
    $log.ScrollToCaret()
}

# ---- 后台进程运行器: 流式读取模块输出(GBK) ----
$script:Proc = $null
function GUI-LockButtons([bool]$lock) {
    foreach ($b in $script:btns.Values) { $b.Enabled = -not $lock }
}
function GUI-RunFeature($f) {
    if ($script:Proc -and -not $script:Proc.HasExited) {
        [Windows.Forms.MessageBox]::Show('有功能在跑，等它结束再点。', '提示', 'OK', 'Information') | Out-Null
        return
    }
    if ($f.Key -eq '6') { GUI-RunAVSelect; return }
    if ($f.Key -ne '3') {
        $r = [Windows.Forms.MessageBox]::Show(
            ("即将执行：$($f.Name)`n`n$($f.Desc)`n`n确认执行？（中途自动确认，不用再敲键盘）"),
            '确认执行', 'YesNo', 'Warning', 'Button2')
        if ($r -ne [Windows.Forms.DialogResult]::Yes) { return }
    }
    GUI-StartProc -bat $f.Bat -modargs $f.Arg -title $f.Name
}

function GUI-StartProc([string]$bat, [string]$modargs, [string]$title) {
    $env:YINFU_AUTO = '1'
    $psi = New-Object Diagnostics.ProcessStartInfo
    $psi.FileName = "$env:SystemRoot\System32\cmd.exe"
    if ($modargs) { $psi.Arguments = "/c call `"$ToolDir\$bat`" $modargs" }
    else          { $psi.Arguments = "/c call `"$ToolDir\$bat`" MAIN" }
    $psi.WorkingDirectory = $ToolDir
    $psi.UseShellExecute = $false
    $psi.RedirectStandardOutput = $true
    $psi.RedirectStandardError = $true
    $psi.CreateNoWindow = $true
    $psi.StandardOutputEncoding = [Text.Encoding]::GetEncoding(936)
    $psi.StandardErrorEncoding = [Text.Encoding]::GetEncoding(936)
    $p = New-Object Diagnostics.Process
    $p.StartInfo = $psi
    $p.EnableRaisingEvents = $true
    $p.add_OutputDataReceived({ param($s, $e) if ($e.Data) { $form.BeginInvoke([Action]{ Write-Log $e.Data ([Drawing.Color]::FromArgb(219,228,245)) }.GetNewClosure()) } })
    $p.add_ErrorDataReceived({ param($s, $e) if ($e.Data) { $form.BeginInvoke([Action]{ Write-Log $e.Data ([Drawing.Color]::FromArgb(255,140,140)) }.GetNewClosure()) } })
    $p.add_Exited({ $form.BeginInvoke([Action]{
        Write-Log "===== 完成 =====" ([Drawing.Color]::FromArgb(63,214,143))
        GUI-LockButtons $false
        $script:Proc = $null
    }.GetNewClosure()) })
    [void]$p.Start()
    $p.BeginOutputReadLine()
    $p.BeginErrorReadLine()
    $script:Proc = $p
    GUI-LockButtons $true
    Write-Log "===== [$title] 开始 =====" ([Drawing.Color]::FromArgb(255,180,84))
}

# ---- 杀软安装包子窗口 ----
function GUI-RunAVSelect {
    $entries = @()
    $cfg = Join-Path $ToolDir '杀毒软件安装包配置'
    $intel = Join-Path $ToolDir 'intel.txt'
    foreach ($src in @($intel, $cfg)) {
        if (-not (Test-Path -LiteralPath $src)) { continue }
        foreach ($line in [IO.File]::ReadAllLines($src, [Text.Encoding]::GetEncoding(936))) {
            $t = $line.Trim()
            if ($t -match '^#') { continue }
            $parts = $t -split '\|'
            if ($parts.Count -ge 3 -and $parts[0].Trim()) {
                $entries += [pscustomobject]@{ Name=$parts[0].Trim(); Local=$parts[1].Trim(); Url=$parts[2].Trim() }
            }
        }
    }
    $entries = @($entries | Sort-Object Name -Unique)
    if (-not $entries) {
        [Windows.Forms.MessageBox]::Show('没读到杀软条目，看一下「杀毒软件安装包配置」文件。', '提示') | Out-Null
        return
    }
    $dlg = New-Object Windows.Forms.Form
    $dlg.Text = '获取杀毒软件安装包'
    $dlg.Size = New-Object Drawing.Size(560, 430)
    $dlg.StartPosition = 'CenterParent'
    $dlg.FormBorderStyle = 'FixedSingle'
    $dlg.BackColor = [Drawing.Color]::FromArgb(24, 30, 46)
    $lb = New-Object Windows.Forms.ListBox
    $lb.Location = New-Object Drawing.Point(14, 12)
    $lb.Size = New-Object Drawing.Size(516, 280)
    $lb.Font = New-Object Drawing.Font('微软雅黑', 10)
    $lb.BackColor = [Drawing.Color]::FromArgb(12,17,29)
    $lb.ForeColor = [Drawing.Color]::FromArgb(219,228,245)
    foreach ($e in $entries) { [void]$lb.Items.Add($e.Name) }
    $lb.SelectedIndex = 0
    $dlg.Controls.Add($lb)
    $bGo = New-Object Windows.Forms.Button
    $bGo.Text = '自动获取并运行（本地优先，没有就下载）'
    $bGo.Location = New-Object Drawing.Point(14, 306)
    $bGo.Size = New-Object Drawing.Size(360, 44)
    $bGo.FlatStyle = 'Flat'
    $bGo.BackColor = [Drawing.Color]::FromArgb(29,38,56)
    $bGo.ForeColor = [Drawing.Color]::FromArgb(63,214,143)
    $dlg.Controls.Add($bGo)
    $bOpen = New-Object Windows.Forms.Button
    $bOpen.Text = '打开下载目录'
    $bOpen.Location = New-Object Drawing.Point(388, 306)
    $bOpen.Size = New-Object Drawing.Size(142, 44)
    $bOpen.FlatStyle = 'Flat'
    $bOpen.BackColor = [Drawing.Color]::FromArgb(29,38,56)
    $bOpen.ForeColor = [Drawing.Color]::FromArgb(219,228,245)
    $dlg.Controls.Add($bOpen)
    $bGo.Add_Click({
        $n = $lb.SelectedIndex
        if ($n -lt 0) { return }
        $sel = $entries[$n]
        $dlg.Close()
        GUI-StartProc -bat 'YinHuFix_AVInstall.bat' -modargs "MAIN $($n + 1)" -title ('杀软安装包: ' + $sel.Name)
    })
    $bOpen.Add_Click({
        $dl = Join-Path $ToolDir '下载'
        if (-not (Test-Path $dl)) { New-Item -ItemType Directory -Path $dl -Force | Out-Null }
        Start-Process explorer.exe -ArgumentList ("`"$dl`"")
    })
    [void]$dlg.ShowDialog()
}

# ---- 更新探测: 后台进程 + 定时器读结果(不阻塞 UI) ----
$script:UpdProc = $null
$script:UpdFile = Join-Path $env:TEMP 'sfk_gui_upd.txt'
$timerUpd = New-Object Windows.Forms.Timer
$timerUpd.Interval = 1000
$timerUpd.Add_Tick({
    if ($script:UpdProc -and $script:UpdProc.HasExited) {
        $timerUpd.Stop()
        $line = $null
        if (Test-Path $script:UpdFile) {
            $line = Get-Content -LiteralPath $script:UpdFile -Encoding Default |
                Where-Object { $_ -like 'BGRESULT=*' } | Select-Object -First 1
        }
        if (-not $line) {
            $lblUpd.Text = '更新状态：离线（网络不可达）'
            return
        }
        $v = ($line -split '=', 2)[1]
        if ($v -eq 'OK') {
            $lblUpd.Text = "更新状态：已是最新 v$Ver"
            $lblUpd.ForeColor = [Drawing.Color]::FromArgb(63,214,143)
        } elseif ($v -like 'NEW *') {
            $nv = $v.Substring(4)
            $lblUpd.Text = "更新状态：有新版本 v$nv，点[8]更新"
            $lblUpd.ForeColor = [Drawing.Color]::FromArgb(255,92,108)
            Write-Log "云端发现新版本 v$nv — 银狐变种更新很快，新版带有新的黑白名单和检测规则，建议尽快更新。" ([Drawing.Color]::FromArgb(255,92,108))
        } else {
            $lblUpd.Text = '更新状态：离线（网络不可达）'
        }
    }
})
function GUI-StartUpdateProbe {
    $lblUpd.Text = '更新状态：检测中…'
    Remove-Item $script:UpdFile -Force -ErrorAction SilentlyContinue
    $psi = New-Object Diagnostics.ProcessStartInfo
    $psi.FileName = "$env:SystemRoot\System32\cmd.exe"
    $psi.Arguments = "/c call `"$ToolDir\YinHuFix_SelfUpdate.bat`" BGPROBE >`"$script:UpdFile`" 2>&1"
    $psi.WorkingDirectory = $ToolDir
    $psi.UseShellExecute = $false
    $psi.CreateNoWindow = $true
    $script:UpdProc = [Diagnostics.Process]::Start($psi)
    $timerUpd.Start()
}

# ---- 退出确认: 有进程运行时提示 ----
$form.Add_FormClosing({
    if ($script:Proc -and -not $script:Proc.HasExited) {
        $r = [Windows.Forms.MessageBox]::Show('功能仍在运行, 确定退出? (后台进程将继续完成)', '确认', 'YesNo', 'Warning')
        if ($r -ne [Windows.Forms.DialogResult]::Yes) { $_.Cancel = $true }
    }
})

Write-Log "银狐病毒综合修复工具 GUI v$Ver 已启动（管理员）。点左侧功能开始，悬停按钮可以看说明。" ([Drawing.Color]::FromArgb(63,214,143))
$form.Add_Shown({ GUI-StartUpdateProbe })
[void]$form.ShowDialog()
