﻿# YinHuFix GUI @NovaPupil_  v1.10.20261031
# PowerShell WinForms 界面壳: 复用各功能模块(YINFU_AUTO=1 自动确认), 实时日志, 更新横幅
# 要求: Windows 10 1903+ / PowerShell 5.1(系统内置) / 管理员权限(自动提权)
$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing
[Windows.Forms.Application]::EnableVisualStyles()
[Console]::OutputEncoding = [Text.Encoding]::GetEncoding(936)

$ToolDir = Split-Path -Parent $MyInvocation.MyCommand.Path

# ---- 管理员自检与自提权 ----
$wi = [Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()
if (-not $wi.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) {
    Start-Process -FilePath 'powershell.exe' -Verb RunAs -ArgumentList @(
        '-NoProfile', '-ExecutionPolicy', 'Bypass', '-WindowStyle', 'Hidden',
        '-File', ('"{0}"' -f $PSCommandPath)
    )
    exit 0
}

# ---- 读取本地版本(主程序 TOOLVER) ----
$Ver = '0'
$mainBat = Get-ChildItem -LiteralPath $ToolDir -Filter 'YinHuFix_*.bat' |
    Where-Object { $_.Name -notmatch 'AVInstall|FixUpdate|UnblockAV|KillVariant|SelfUpdate|HostsClean|WDAC|ScanHide|SysReg' } |
    Select-Object -First 1
if ($mainBat) {
    $tl = Select-String -LiteralPath $mainBat.FullName -Pattern '^REM TOOLVER=(.+)$' |
        Select-Object -First 1
    if ($tl) { $Ver = $tl.Matches[0].Groups[1].Value.Trim() }
}

# ---- 功能定义 ----
# Cat: fix=修复(蓝) safe=只读(绿) warn=高风险(橙) dl=下载(白) online=在线(青)
$Features = @(
    @{ Key='1'; Cat='fix';    Name='修复 WDAC 应用控制拦截'; Bat='YinHuFix_WDAC.bat';      Arg='MAIN';
       Desc="清除可疑的 WDAC 策略文件，恢复被篡改的系统限制项。`n若有改动会提示重启（工具不会自动重启）。" }
    @{ Key='2'; Cat='warn';   Name='解除杀毒软件限制';   Bat='YinHuFix_UnblockAV.bat'; Arg='MAIN';
       Desc="解除木马对杀毒软件的压制：清理策略、结束劫持进程、停止高置信度可疑服务。`nSangfor 服务将跳过（停止会导致 VPN 断开）。`n仅建议在确认中招、杀毒软件无法打开的机器上使用。" }
    @{ Key='3'; Cat='safe';   Name='隐藏进程与启动项扫描';     Bat='YinHuFix_ScanHide.bat';  Arg='MAIN';
       Desc="扫描隐藏进程、启动项、计划任务、Public 目录释放物、Defender 状态及 C2 回连。`n仅扫描报告，不做任何处置。" }
    @{ Key='4'; Cat='fix';    Name='恢复 Windows 更新';      Bat='YinHuFix_FixUpdate.bat'; Arg='MAIN';
       Desc="恢复被禁用的更新服务，仅清理阻断更新的策略值。`n用户主动暂停的更新计划将保留。" }
    @{ Key='5'; Cat='fix';    Name='清除系统限制注册表项';     Bat='YinHuFix_SysReg.bat';    Arg='MAIN';
       Desc="恢复被禁用的任务管理器、注册表编辑器、命令提示符、运行对话框、UAC 及 Defender。" }
    @{ Key='6'; Cat='dl';     Name='获取杀毒软件安装包';     Bat='YinHuFix_AVInstall.bat'; Arg='';
       Desc="列出常用杀毒软件，本地已有安装包则直接使用，否则自动下载。`n列表包含云端策略下发的条目。" }
    @{ Key='7'; Cat='warn';   Name='木马变体专项清除';         Bat='YinHuFix_KillVariant.bat'; Arg='MAIN';
       Desc="针对门控投递器族变体：IOC 计划任务、Public 释放物、伪装更新包、Defender 致盲、C2 回连。`n确认后一键处置。" }
    @{ Key='8'; Cat='dl';     Name='检查更新';               Bat='YinHuFix_SelfUpdate.bat'; Arg='MAIN';
       Desc="检查新版本。Gitee 路线不可达时自动切换 GitHub，下载前校验 SHA-256。" }
    @{ Key='9'; Cat='fix';    Name='重置 hosts 配置';    Bat='YinHuFix_HostsClean.bat'; Arg='MAIN';
       Desc="备份当前 hosts 至 hosts_backup 目录后恢复系统默认，并刷新 DNS 缓存。`n适用于 hosts 被篡改（屏蔽杀软官网、指向恶意站点）的场景。" }
    @{ Key='T'; Cat='online'; Name='微步云沙箱在线检测';    Bat=''; Arg='';
       Desc="在默认浏览器中打开微步在线分析页 s.threatbook.com。`n可将文件哈希粘贴至页面查询，也支持上传样本进行动态分析。`n注意：上传样本即提交至第三方云端，涉隐私文件请勿上传。`n若页面无法打开，多为 hosts 被篡改或网络中断，请先使用功能 9。" }
)

# ---- 配色 ----
$C = @{
    Bg       = [Drawing.Color]::FromArgb(24,30,46)    # 窗体底
    Header   = [Drawing.Color]::FromArgb(17,22,36)    # 头部/状态栏底
    Panel    = [Drawing.Color]::FromArgb(20,26,40)    # 按钮面板底
    BtnBase  = [Drawing.Color]::FromArgb(29,38,56)    # 按钮常态底
    BtnHover = [Drawing.Color]::FromArgb(40,52,76)    # 按钮悬停底
    Log      = [Drawing.Color]::FromArgb(10,14,24)    # 日志底
    Text     = [Drawing.Color]::FromArgb(230,238,250) # 主文字
    Dim      = [Drawing.Color]::FromArgb(143,160,192) # 次要文字
    Fix      = [Drawing.Color]::FromArgb(96,160,255)  # 修复类
    Safe     = [Drawing.Color]::FromArgb(63,214,143)  # 只读/成功
    Warn     = [Drawing.Color]::FromArgb(255,180,84)  # 影响大
    Dl       = [Drawing.Color]::FromArgb(219,228,245) # 下载/中性
    Online   = [Drawing.Color]::FromArgb(96,211,255)  # 在线
    Err      = [Drawing.Color]::FromArgb(255,120,120) # 错误
}

# ---- 主窗体 ----
$form = New-Object Windows.Forms.Form
$form.Text = "银狐病毒综合修复工具 GUI v$Ver @NovaPupil_"
$form.Size = New-Object Drawing.Size(1020, 724)
$form.StartPosition = 'CenterScreen'
$form.FormBorderStyle = 'FixedSingle'
$form.MaximizeBox = $false
$form.Font = New-Object Drawing.Font('微软雅黑', 9)
$form.BackColor = $C.Bg

# ---- 头部标题区 ----
$hd = New-Object Windows.Forms.Panel
$hd.Location = New-Object Drawing.Point(0, 0)
$hd.Size = New-Object Drawing.Size(1014, 62)
$hd.BackColor = $C.Header
$form.Controls.Add($hd)

$lblTitle = New-Object Windows.Forms.Label
$lblTitle.Text = '银狐病毒综合修复工具'
$lblTitle.Font = New-Object Drawing.Font('微软雅黑', 13, [Drawing.FontStyle]::Bold)
$lblTitle.ForeColor = $C.Text
$lblTitle.Location = New-Object Drawing.Point(18, 8)
$lblTitle.AutoSize = $true
$hd.Controls.Add($lblTitle)

$lblVer = New-Object Windows.Forms.Label
$lblVer.Text = "v$Ver　·　所有处置操作均需确认后执行，日志实时显示"
$lblVer.ForeColor = $C.Dim
$lblVer.Location = New-Object Drawing.Point(20, 37)
$lblVer.AutoSize = $true
$hd.Controls.Add($lblVer)

$lblUpd = New-Object Windows.Forms.Label
$lblUpd.Text = '更新状态：检测中…'
$lblUpd.ForeColor = $C.Dim
$lblUpd.Location = New-Object Drawing.Point(760, 22)
$lblUpd.AutoSize = $true
$hd.Controls.Add($lblUpd)

# ---- 分区标签 ----
function New-SecLabel([string]$text, [int]$x, [int]$y) {
    $l = New-Object Windows.Forms.Label
    $l.Text = $text
    $l.ForeColor = $C.Dim
    $l.Font = New-Object Drawing.Font('微软雅黑', 9, [Drawing.FontStyle]::Bold)
    $l.Location = New-Object Drawing.Point($x, $y)
    $l.AutoSize = $true
    $form.Controls.Add($l)
}
New-SecLabel '功 能' 18 70
New-SecLabel '功能说明' 328 70
New-SecLabel '运 行 日 志' 14 510

# ---- 功能按钮区 ----
$btnPanel = New-Object Windows.Forms.Panel
$btnPanel.Location = New-Object Drawing.Point(14, 92)
$btnPanel.Size = New-Object Drawing.Size(300, 410)
$btnPanel.BackColor = $C.Panel
$form.Controls.Add($btnPanel)

# ---- 功能说明面板(单击按钮显示说明; 任务运行时切换为结果摘要) ----
$descPanel = New-Object Windows.Forms.Panel
$descPanel.Location = New-Object Drawing.Point(324, 92)
$descPanel.Size = New-Object Drawing.Size(668, 410)
$descPanel.BackColor = $C.Panel
$form.Controls.Add($descPanel)

$lblDescName = New-Object Windows.Forms.Label
$lblDescName.Text = '使用说明'
$lblDescName.Font = New-Object Drawing.Font('微软雅黑', 12, [Drawing.FontStyle]::Bold)
$lblDescName.ForeColor = $C.Text
$lblDescName.Location = New-Object Drawing.Point(18, 16)
$lblDescName.AutoSize = $true
$descPanel.Controls.Add($lblDescName)

$lblDescText = New-Object Windows.Forms.Label
$lblDescText.Text = "单击左侧功能查看用途与注意事项，双击同一按钮即运行。`n`n任务运行或结束时，本区域会实时显示结果摘要：发现/处置/失败计数与最近输出。`n`n按钮颜色代表功能类别：蓝色为系统修复，绿色为只读扫描，橙色为高风险操作，白色为下载与更新，青色为在线服务。"
$lblDescText.Font = New-Object Drawing.Font('微软雅黑', 9.5)
$lblDescText.ForeColor = $C.Dim
$lblDescText.Location = New-Object Drawing.Point(18, 54)
$lblDescText.Size = New-Object Drawing.Size(632, 300)
$descPanel.Controls.Add($lblDescText)

$lblLegend = New-Object Windows.Forms.Label
$lblLegend.Text = '全部操作执行前均会弹出确认框，未确认不会改动系统。'
$lblLegend.ForeColor = $C.Dim
$lblLegend.Location = New-Object Drawing.Point(18, 378)
$lblLegend.AutoSize = $true
$descPanel.Controls.Add($lblLegend)

# ---- 运行摘要控件: 计数行(13pt 加粗醒目) + 最近 12 条输出(关键标记行 10.5pt 加粗色字) ----
$FHit    = New-Object Drawing.Font('微软雅黑', 10.5, [Drawing.FontStyle]::Bold)
$FHitDim = New-Object Drawing.Font('微软雅黑', 9)
$lblCntF = New-Object Windows.Forms.Label
$lblCntF.Location = New-Object Drawing.Point(18, 44)
$lblCntF.AutoSize = $true
$lblCntF.Font = New-Object Drawing.Font('微软雅黑', 13, [Drawing.FontStyle]::Bold)
$descPanel.Controls.Add($lblCntF)
$lblCntX = New-Object Windows.Forms.Label
$lblCntX.Location = New-Object Drawing.Point(248, 44)
$lblCntX.AutoSize = $true
$lblCntX.Font = New-Object Drawing.Font('微软雅黑', 13, [Drawing.FontStyle]::Bold)
$descPanel.Controls.Add($lblCntX)
$lblCntE = New-Object Windows.Forms.Label
$lblCntE.Location = New-Object Drawing.Point(478, 44)
$lblCntE.AutoSize = $true
$lblCntE.Font = New-Object Drawing.Font('微软雅黑', 13, [Drawing.FontStyle]::Bold)
$descPanel.Controls.Add($lblCntE)
$script:HitsLbls = @()
for ($i = 0; $i -lt 11; $i++) {
    $l = New-Object Windows.Forms.Label
    $l.Location = New-Object Drawing.Point(18, (84 + $i * 26))
    $l.Size = New-Object Drawing.Size(632, 26)
    $l.TextAlign = 'MiddleLeft'
    $l.AutoEllipsis = $true
    $descPanel.Controls.Add($l)
    $script:HitsLbls += $l
}
# 右下角大字下载进度: 下载 XX% / 下载完成 / 下载失败(仅下载类任务显示)
$lblDl = New-Object Windows.Forms.Label
$lblDl.Location = New-Object Drawing.Point(18, 374)
$lblDl.Size = New-Object Drawing.Size(614, 30)
$lblDl.TextAlign = 'MiddleRight'
$lblDl.Font = New-Object Drawing.Font('微软雅黑', 15, [Drawing.FontStyle]::Bold)
$lblDl.Text = ''
$descPanel.Controls.Add($lblDl)
function GUI-SummaryVisible([bool]$on) {
    $lblDescText.Visible = -not $on
    $lblLegend.Visible = -not $on
    foreach ($c in (@($lblCntF, $lblCntX, $lblCntE, $lblDl) + $script:HitsLbls)) { $c.Visible = $on }
}
GUI-SummaryVisible $false

# ---- 运行摘要: 说明面板在任务运行/结束时切换为实时结果摘要 ----
# 模块日志的统一标记行: [发现]/[异常]/[警告]=可疑项, [已删除]/[已恢复]/[已结束]/[已启动]/[OK]=已处置, [失败]/[错误]=失败
# 摘要与日志互补: 只放关键事件(大号加粗色字)+一行"当前步骤"; 过程行([扫描]/[下载]等)不重复进摘要
# curl 进度帧不进摘要, 只驱动右下角大字: 下载 XX% → 下载完成/下载失败
$script:RunTitle = ''
$script:RunStat = $null
$script:RunStep = ''       # 最近一条过程行, 作为"当前步骤"展示
$script:RunKeys = @()      # 关键事件, 每项 { T=纯文本, K=warn|ok|err }
$script:RunKeysMax = 10
$script:RunDl = ''         # ''=无下载, 'pct'=下载中(有百分比帧), 'done'=已定格
function GUI-DlDone([bool]$ok) {
    $script:RunDl = 'done'
    $lblDl.Text = if ($ok) { '下载完成' } else { '下载失败' }
    $lblDl.ForeColor = if ($ok) { $C.Safe } else { $C.Err }
}
function GUI-FeedSummary([string]$ln) {
    if (-not $script:RunTitle) { return }
    $t = ($ln -replace "\x1b\[[0-9;]*m", '')
    if ($t -match "`r") { $t = ($t -split "`r")[-1] }   # curl 进度帧以 \r 刷写, 兜底取最后一帧
    $t = $t.Trim()
    if ($t -eq '' -or $t -match '^=+$') { return }
    if ($t -match '^(\d{1,3})\s') {
        $script:RunDl = 'pct'
        $lblDl.Text = "下载 {0}%" -f [int]$Matches[1]
        $lblDl.ForeColor = $C.Warn
        return
    }
    if ($t -match '^\[') {
        # 下载后的第一条标记行(任意类别): 右下角进度定格
        if ($script:RunDl -eq 'pct') { GUI-DlDone ($t -notmatch '^\[(失败|错误)\]') }
        if ($t -ne $script:RunStep) { $script:RunStep = $t; GUI-ShowSummary $false }
    }
    $k = $null
    if     ($t -match '^\[(发现|异常|警告)\]') { $k = 'warn'; $script:RunStat.Found++ }
    elseif ($t -match '^\[(已删除|已恢复|已结束|已启动|OK)\]') { $k = 'ok'; $script:RunStat.Fixed++ }
    elseif ($t -match '^\[(失败|错误)\]') { $k = 'err'; $script:RunStat.Fail++ }
    else { return }
    $script:RunKeys = @($script:RunKeys + [pscustomobject]@{ T = $t; K = $k })
    if ($script:RunKeys.Count -gt $script:RunKeysMax) {
        $script:RunKeys = @($script:RunKeys | Select-Object -Last $script:RunKeysMax)
    }
    GUI-ShowSummary $false
}
function GUI-ShowSummary([bool]$done) {
    if (-not $script:RunStat) { return }
    GUI-SummaryVisible $true
    $s = $script:RunStat
    $lblDescName.Text = ("{0}：{1}" -f $(if ($done) { '已完成' } else { '正在执行' }), $script:RunTitle)
    $lblDescName.ForeColor = if ($done) { $C.Safe } else { $C.Warn }
    $lblCntF.Text = "发现可疑项：{0}" -f $s.Found
    $lblCntF.ForeColor = $C.Warn
    $lblCntX.Text = "已处置：{0}" -f $s.Fixed
    $lblCntX.ForeColor = $C.Safe
    $lblCntE.Text = "失败：{0}" -f $s.Fail
    $lblCntE.ForeColor = if ($s.Fail -gt 0) { $C.Err } else { $C.Dim }
    for ($i = 0; $i -lt $script:HitsLbls.Count; $i++) { $script:HitsLbls[$i].Text = '' }
    if ($script:RunStep) {
        $script:HitsLbls[0].Text = "当前：{0}" -f $script:RunStep
        $script:HitsLbls[0].ForeColor = $C.Dim
        $script:HitsLbls[0].Font = $FHitDim
    }
    $base = 1
    foreach ($h in $script:RunKeys) {
        if ($base -ge $script:HitsLbls.Count) { break }
        $l = $script:HitsLbls[$base]
        $l.Text = $h.T
        switch ($h.K) {
            'warn'  { $l.ForeColor = $C.Warn; $l.Font = $FHit }
            'ok'    { $l.ForeColor = $C.Safe; $l.Font = $FHit }
            'err'   { $l.ForeColor = $C.Err;  $l.Font = $FHit }
        }
        $base++
    }
    if ($script:RunKeys.Count -eq 0 -and -not $script:RunStep) {
        $script:HitsLbls[0].Text = if ($done) { '本功能未发现需要处理的项目。' } else { '正在分析系统状态…' }
        $script:HitsLbls[0].ForeColor = $C.Dim
        $script:HitsLbls[0].Font = $FHitDim
    }
}

# 单击=右侧显示该功能说明; 运行中面板锁定为结果摘要, 不受点击影响
function GUI-ShowFeature($f) {
    if ($script:RunProc -and -not $script:RunProc.HasExited) { return }
    $lblDescName.Text = "[$($f.Key)] $($f.Name)"
    $lblDescName.ForeColor = $C[$f.Cat]
    $lblDescText.Text = $f.Desc
    GUI-SummaryVisible $false
}
# 双击判定: Button 不触发 DoubleClick 事件(StandardDoubleClick 样式关闭),
# 用同一按钮两次 Click 间隔小于系统双击时长来判定
$script:LkBtn = $null
$script:LkTick = 0

$tip = New-Object Windows.Forms.ToolTip
$tip.AutoPopDelay = 8000; $tip.InitialDelay = 300
$script:btns = @{}
$y = 4
foreach ($f in $Features) {
    $b = New-Object Windows.Forms.Button
    $b.Text = "[$($f.Key)] $($f.Name)"
    $b.Tag = $f
    $b.Size = New-Object Drawing.Size(288, 36)
    $b.Location = New-Object Drawing.Point(6, $y)
    $b.FlatStyle = 'Flat'
    $b.FlatAppearance.BorderSize = 0
    $b.BackColor = $C.BtnBase
    $b.ForeColor = $C[$f.Cat]          # 类别色: 蓝=修复 绿=只读 橙=高风险 白=下载 青=在线
    $b.TextAlign = 'MiddleLeft'
    $b.Padding = New-Object Windows.Forms.Padding(10, 0, 0, 0)
    $b.Cursor = 'Hand'
    # 单击: 右侧显示该功能说明(悬停不再切换, 避免鼠标扫过时内容被切走)
    # 快速再点同一按钮(双击): 运行该功能
    # 处理器内 try/catch 兜底: 处理器抛异常会弹系统 JIT 调试框, 必须拦截并写日志
    $b.Add_Click({
        try {
            $f = $this.Tag
            GUI-ShowFeature $f
            $now = [Environment]::TickCount
            if ($script:LkBtn -eq $this -and ($now - $script:LkTick) -lt [Windows.Forms.SystemInformation]::DoubleClickTime) {
                $script:LkBtn = $null
                GUI-RunFeature $f
            } else {
                $script:LkBtn = $this
                $script:LkTick = $now
            }
        } catch {
            Write-Log "[界面] 按钮处理出错: $($_.Exception.Message)" ([Drawing.Color]::FromArgb(255,140,140))
        }
    })
    # 悬停仅增亮底色
    $b.Add_MouseEnter({ if ($this.Enabled) { $this.BackColor = $C.BtnHover } })
    $b.Add_MouseLeave({ $this.BackColor = $C.BtnBase })
    $tip.SetToolTip($b, $f.Desc)
    $btnPanel.Controls.Add($b)
    $script:btns[$f.Key] = $b
    $y += 40
}

# ---- 日志区(底部横条) ----
$log = New-Object Windows.Forms.RichTextBox
$log.Location = New-Object Drawing.Point(14, 532)
$log.Size = New-Object Drawing.Size(978, 112)
$log.BorderStyle = 'FixedSingle'
$log.ReadOnly = $true
$log.BackColor = $C.Log
$log.ForeColor = [Drawing.Color]::FromArgb(184,216,255)
$log.Font = New-Object Drawing.Font('Consolas', 9)
$log.DetectUrls = $false
$form.Controls.Add($log)

# ---- 底部状态栏 ----
$sb = New-Object Windows.Forms.Panel
$sb.Location = New-Object Drawing.Point(0, 650)
$sb.Size = New-Object Drawing.Size(1014, 32)
$sb.BackColor = $C.Header
$form.Controls.Add($sb)

$lblStatus = New-Object Windows.Forms.Label
$lblStatus.Text = '就绪'
$lblStatus.ForeColor = $C.Safe
$lblStatus.Location = New-Object Drawing.Point(14, 8)
$lblStatus.AutoSize = $true
$sb.Controls.Add($lblStatus)

$lblHint = New-Object Windows.Forms.Label
$lblHint.Text = '单击查看功能说明 · 双击运行 · 颜色区分功能类别'
$lblHint.ForeColor = $C.Dim
$lblHint.Location = New-Object Drawing.Point(700, 8)
$lblHint.AutoSize = $true
$sb.Controls.Add($lblHint)

function Set-Status([string]$text, $color) {
    $lblStatus.Text = $text
    $lblStatus.ForeColor = $color
}

function Write-Log([string]$text, $color) {
    if ($form.IsDisposed -or -not $log.IsHandleCreated) { return }
    $log.SelectionStart = $log.TextLength
    $log.SelectionLength = 0
    $log.SelectionColor = $color
    foreach ($line in ($text -split "`r?`n")) {
        $log.AppendText(($line -replace "\x1b\[[0-9;]*m", '') + "`n")
    }
    $log.SelectionColor = $log.ForeColor
    $log.ScrollToCaret()
}

# ---- 后台进程运行器: 输出落文件, UI 定时器增量读取 ----
# 不用 .NET 事件回调(add_OutputDataReceived 在线程池线程触发, PowerShell 脚本块
# 在无 Runspace 的线程上执行会异常并炸掉整个 GUI); 改为与启动探测一致的文件流模式
$script:RunProc = $null
$script:RunFile = $null
$script:RunOff  = 0
$script:RunDone = 0
$script:RunTail = ''
$script:RunDec  = $null
function GUI-LockButtons([bool]$lock) {
    foreach ($b in $script:btns.Values) { $b.Enabled = -not $lock }
}
$timerRun = New-Object Windows.Forms.Timer
$timerRun.Interval = 200
$timerRun.Add_Tick({
    try {
        $p = $script:RunProc
        if (-not $p) { $timerRun.Stop(); return }
        if ($script:RunFile -and (Test-Path -LiteralPath $script:RunFile)) {
            $fs = $null
            try {
                $fs = [IO.File]::Open($script:RunFile, [IO.FileMode]::Open, [IO.FileAccess]::Read,
                      [IO.FileShare]([IO.FileShare]::Read -bor [IO.FileShare]::Write -bor [IO.FileShare]::Delete))
                if ($fs.Length -gt $script:RunOff) {
                    [void]$fs.Seek($script:RunOff, 'Begin')
                    $buf = New-Object byte[] ([int]($fs.Length - $script:RunOff))
                    $n = $fs.Read($buf, 0, $buf.Length)
                    if ($n -gt 0) {
                        $script:RunOff += $n
                        # Decoder.GetChars 在 .NET Framework 只有 5 参数重载(写入目标 char[]),
                        # 先 GetCharCount 取长度再转换; Decoder 保留状态可正确处理跨块的 GBK 双字节字符
                        $cc = $script:RunDec.GetCharCount($buf, 0, $n)
                        if ($cc -gt 0) {
                            $ch = New-Object char[] $cc
                            [void]$script:RunDec.GetChars($buf, 0, $n, $ch, 0)
                            $script:RunTail += (-join $ch)
                        }
                    }
                }
            } finally { if ($fs) { $fs.Close() } }
        }
        if ($script:RunTail) {
            $i = $script:RunTail.LastIndexOf("`n")
            if ($i -ge 0) {
                $lines = $script:RunTail.Substring(0, $i) -split "\r\n|\r|\n"
                $script:RunTail = $script:RunTail.Substring($i + 1)
                foreach ($ln in $lines) {
                    if ($ln.Trim() -eq '') { continue }
                    Write-Log $ln ([Drawing.Color]::FromArgb(219,228,245))
                    GUI-FeedSummary $ln
                }
            }
        }
        if ($p.HasExited) {
            $drained = $true
            if ($script:RunFile -and (Test-Path -LiteralPath $script:RunFile)) {
                if ((Get-Item -LiteralPath $script:RunFile -Force).Length -gt $script:RunOff) { $drained = $false }
            }
            if ($drained -and $script:RunTail) {
                if ($script:RunTail.Trim() -ne '') { Write-Log $script:RunTail ([Drawing.Color]::FromArgb(219,228,245)) }
                $script:RunTail = ''
            }
            if ($drained -and -not $script:RunTail) {
                $script:RunDone++
                if ($script:RunDone -ge 3) {
                    $timerRun.Stop()
                    Write-Log "===== 完成 =====" ([Drawing.Color]::FromArgb(63,214,143))
                    GUI-ShowSummary $true
                    Set-Status '就绪' $C.Safe
                    GUI-LockButtons $false
                    $script:RunProc = $null
                }
            } else { $script:RunDone = 0 }
        }
    } catch {
        Write-Log "[界面] 读取模块输出时出错: $($_.Exception.Message)" ([Drawing.Color]::FromArgb(255,140,140))
    }
})
# ---- 统一风格对话框: 替代系统 MessageBox(与主界面同为暗色) ----
# 返回被点击按钮的文本; 默认焦点在最后一个按钮(防误触, 等价原 MessageBox 的 Button2 约定)
function GUI-MsgBox([string]$title, [string]$text, [string[]]$buttonTexts, [Drawing.Color]$accent) {
    $dlg = New-Object Windows.Forms.Form
    $dlg.Text = $title
    $dlg.Size = New-Object Drawing.Size(480, 260)
    $dlg.StartPosition = 'CenterParent'
    $dlg.FormBorderStyle = 'FixedSingle'
    $dlg.MaximizeBox = $false
    $dlg.BackColor = $C.Bg
    $dlg.TopMost = $true

    $lt = New-Object Windows.Forms.Label
    $lt.Text = $title
    $lt.Font = New-Object Drawing.Font('微软雅黑', 12, [Drawing.FontStyle]::Bold)
    $lt.ForeColor = $accent
    $lt.Location = New-Object Drawing.Point(20, 16)
    $lt.AutoSize = $true
    $dlg.Controls.Add($lt)

    $lx = New-Object Windows.Forms.Label
    $lx.Text = $text
    $lx.Font = New-Object Drawing.Font('微软雅黑', 9.5)
    $lx.ForeColor = $C.Text
    $lx.Location = New-Object Drawing.Point(20, 56)
    $lx.Size = New-Object Drawing.Size(424, 110)
    $dlg.Controls.Add($lx)

    $sel = $null
    $bx = 452
    for ($i = $buttonTexts.Count - 1; $i -ge 0; $i--) {
        $bt = New-Object Windows.Forms.Button
        $bt.Text = $buttonTexts[$i]
        $bt.Tag = $buttonTexts[$i]
        $bt.Size = New-Object Drawing.Size(120, 34)
        $bx -= 132
        $bt.Location = New-Object Drawing.Point($bx, 172)
        $bt.FlatStyle = 'Flat'
        $bt.FlatAppearance.BorderSize = 0
        $bt.BackColor = $C.BtnBase
        if ($i -eq $buttonTexts.Count - 1) { $bt.ForeColor = $C.Dim } else { $bt.ForeColor = $accent }
        $bt.Cursor = 'Hand'
        $bt.Add_MouseEnter({ $this.BackColor = $C.BtnHover })
        $bt.Add_MouseLeave({ $this.BackColor = $C.BtnBase })
        $bt.Add_Click({ $script:msgSel = $this.Tag; $this.FindForm().Close() })
        $dlg.Controls.Add($bt)
        if ($i -eq $buttonTexts.Count - 1) { $dlg.AcceptButton = $bt }
    }
    $script:msgSel = $null
    [void]$dlg.ShowDialog($form)
    return $script:msgSel
}
function GUI-RunFeature($f) {
    if ($script:RunProc -and -not $script:RunProc.HasExited) {
        GUI-MsgBox '提示' '有功能正在运行，请等待其结束后再操作。' @('知道了') $C.Fix | Out-Null
        return
    }
    if ($f.Key -eq '6') { GUI-RunAVSelect; return }
    # 云沙箱按钮: 不经模块进程, 直接开默认浏览器（URL 与 bat 侧 CLOUDSAN 分支一致，改时两处一起改）
    if ($f.Key -eq 'T') {
        try {
            Start-Process 'https://s.threatbook.com/'
            Write-Log '已在默认浏览器中打开微步在线分析页 s.threatbook.com。上传样本将提交至第三方云端，请注意隐私。' ([Drawing.Color]::FromArgb(96,160,255))
        } catch {
            Write-Log "打开浏览器失败: $($_.Exception.Message)。请手动访问 https://s.threatbook.com/" ([Drawing.Color]::FromArgb(255,140,140))
        }
        return
    }
    if ($f.Key -ne '3') {
        $r = GUI-MsgBox '确认执行' ("即将执行：$($f.Name)`n`n$($f.Desc)`n`n运行过程中将自动确认后续操作，是否继续？") @('取消','确认执行') $C.Warn
        if ($r -ne '确认执行') { return }
    }
    GUI-StartProc -bat $f.Bat -modargs $f.Arg -title $f.Name
}

function GUI-StartProc([string]$bat, [string]$modargs, [string]$title) {
    $env:YINFU_AUTO = '1'
    $script:RunTitle = $title
    $script:RunStat = @{ Found = 0; Fixed = 0; Fail = 0 }
    $script:RunStep = ''
    $script:RunKeys = @()
    $script:RunDl = ''
    $lblDl.Text = ''
    $script:LkBtn = $null; $script:LkTick = 0
    $script:RunFile = Join-Path $env:TEMP 'yinfu_gui_run.out'
    Remove-Item -LiteralPath $script:RunFile -Force -ErrorAction SilentlyContinue
    $psi = New-Object Diagnostics.ProcessStartInfo
    $psi.FileName = "$env:SystemRoot\System32\cmd.exe"
    if ($modargs) { $psi.Arguments = "/c call `"$ToolDir\$bat`" $modargs >`"$script:RunFile`" 2>&1" }
    else          { $psi.Arguments = "/c call `"$ToolDir\$bat`" MAIN >`"$script:RunFile`" 2>&1" }
    $psi.WorkingDirectory = $ToolDir
    $psi.UseShellExecute = $false
    $psi.CreateNoWindow = $true
    $script:RunProc = [Diagnostics.Process]::Start($psi)
    $script:RunOff  = 0
    $script:RunDone = 0
    $script:RunTail = ''
    $script:RunDec  = [Text.Encoding]::GetEncoding(936).GetDecoder()
    GUI-LockButtons $true
    Set-Status ("正在执行：{0}" -f $title) $C.Warn
    GUI-ShowSummary $false
    Write-Log "===== [$title] 开始 =====" ([Drawing.Color]::FromArgb(255,180,84))
    $timerRun.Start()
}

# ---- 杀软安装包子窗口 ----
function GUI-RunAVSelect {
    $entries = @()
    $cfg = Join-Path $ToolDir '杀毒软件安装包配置'
    $intel = Join-Path $ToolDir 'intel.txt'
    # 顺序规则必须与 YinHuFix_AVInstall.bat 的 :AVLOAD 完全一致:
    # intel.txt 的 av_entry= 在前、配置文件条目在后、各自按文件原序、不排序不去重。
    # GUI 传参 MAIN N 依赖两侧行号一一对应——排序或去重都会造成"选 A 装 B"的错位。
    foreach ($src in @($intel, $cfg)) {
        if (-not (Test-Path -LiteralPath $src)) { continue }
        $isIntel = ($src -eq $intel)
        foreach ($line in [IO.File]::ReadAllLines($src, [Text.Encoding]::GetEncoding(936))) {
            $t = $line.Trim()
            if ($t -match '^#') { continue }
            if ($isIntel) {
                # intel.txt 只有 av_entry= 行是安装包条目(task_name/file_hash/notice 等不是)
                if ($t -notmatch '^av_entry=') { continue }
                $t = $t.Substring(9).Trim()
            }
            if ($t -eq '') { continue }
            $parts = $t -split '\|'
            $n0 = $parts[0].Trim()
            if ($parts.Count -ge 3 -and $n0) {
                $l0 = $parts[1].Trim()
                $u0 = $parts[2].Trim()
                # 去重(先到先得, 云端条目在前=云端优先): 同名, 或同本地路径/同下载地址=同一软件,
                # 与 avinst.bat :AVLOAD 的 :AVADD 规则一致, 两侧行号才能保持一一对应
                if (-not ($entries | Where-Object {
                        $_.Name -eq $n0 -or
                        ($l0 -and $l0 -ne '无' -and $_.Local -eq $l0) -or
                        ($u0 -and $u0 -ne '无' -and $_.Url -eq $u0) })) {
                    $entries += [pscustomobject]@{ Name=$n0; Local=$l0; Url=$u0 }
                }
            }
        }
    }
    if (-not $entries) {
        GUI-MsgBox '提示' '未读取到杀软条目，请检查「杀毒软件安装包配置」文件。' @('知道了') $C.Fix | Out-Null
        return
    }
    $dlg = New-Object Windows.Forms.Form
    $dlg.Text = '获取杀毒软件安装包'
    $dlg.Size = New-Object Drawing.Size(560, 430)
    $dlg.StartPosition = 'CenterParent'
    $dlg.FormBorderStyle = 'FixedSingle'
    $dlg.BackColor = [Drawing.Color]::FromArgb(24, 30, 46)
    $lb = New-Object Windows.Forms.ListBox
    $lb.Location = New-Object Drawing.Point(14, 12)
    $lb.Size = New-Object Drawing.Size(516, 280)
    $lb.Font = New-Object Drawing.Font('微软雅黑', 10)
    $lb.BackColor = [Drawing.Color]::FromArgb(12,17,29)
    $lb.ForeColor = [Drawing.Color]::FromArgb(219,228,245)
    $lb.DrawMode = 'OwnerDrawFixed'
    $lb.ItemHeight = 26
    # 自绘列表项: 名称水平/垂直居中(ListBox 原生不支持居中), 选中项加亮底+绿字
    # DrawString 五参重载在 PS 里会把 Rectangle 误绑到 PointF 版, 必须显式 RectangleF
    $lb.Add_DrawItem({
        try {
            $ev = $_
            if ($ev.Index -lt 0) { return }
            $bg = [Drawing.Color]::FromArgb(12,17,29)
            $fg = [Drawing.Color]::FromArgb(219,228,245)
            if (($ev.State -band [Windows.Forms.DrawItemState]::Selected) -ne 0) {
                $bg = [Drawing.Color]::FromArgb(29,38,56)
                $fg = [Drawing.Color]::FromArgb(63,214,143)
            }
            $fmt = New-Object Drawing.StringFormat
            $fmt.Alignment = 'Center'
            $fmt.LineAlignment = 'Center'
            $bb = New-Object Drawing.SolidBrush($bg)
            $ev.Graphics.FillRectangle($bb, $ev.Bounds)
            $bb.Dispose()
            $fb = New-Object Drawing.SolidBrush($fg)
            $rf = New-Object Drawing.RectangleF($ev.Bounds.X, $ev.Bounds.Y, $ev.Bounds.Width, $ev.Bounds.Height)
            $ev.Graphics.DrawString($this.Items[$ev.Index], $this.Font, $fb, $rf, $fmt)
            $fb.Dispose()
            $fmt.Dispose()
            $ev.DrawFocusRectangle()
        } catch {
            Write-Log "[界面] 列表绘制出错: $($_.Exception.Message)" ([Drawing.Color]::FromArgb(255,140,140))
        }
    })
    foreach ($e in $entries) { [void]$lb.Items.Add($e.Name) }
    $lb.SelectedIndex = 0
    $dlg.Controls.Add($lb)
    $bGo = New-Object Windows.Forms.Button
    $bGo.Text = '自动获取并运行（本地优先，没有就下载）'
    $bGo.Location = New-Object Drawing.Point(14, 306)
    $bGo.Size = New-Object Drawing.Size(360, 44)
    $bGo.FlatStyle = 'Flat'
    $bGo.BackColor = [Drawing.Color]::FromArgb(29,38,56)
    $bGo.ForeColor = [Drawing.Color]::FromArgb(63,214,143)
    $dlg.Controls.Add($bGo)
    $bOpen = New-Object Windows.Forms.Button
    $bOpen.Text = '打开下载目录'
    $bOpen.Location = New-Object Drawing.Point(388, 306)
    $bOpen.Size = New-Object Drawing.Size(142, 44)
    $bOpen.FlatStyle = 'Flat'
    $bOpen.BackColor = [Drawing.Color]::FromArgb(29,38,56)
    $bOpen.ForeColor = [Drawing.Color]::FromArgb(219,228,245)
    $dlg.Controls.Add($bOpen)
    # 单击选中, 双击列表项=确认运行(与主界面"双击运行"一致)
    $goRun = {
        try {
            $n = $lb.SelectedIndex
            if ($n -lt 0) { return }
            $sel = $entries[$n]
            $dlg.Close()
            GUI-StartProc -bat 'YinHuFix_AVInstall.bat' -modargs "MAIN $($n + 1)" -title ('杀软安装包: ' + $sel.Name)
        } catch {
            Write-Log "[界面] 启动获取安装包出错: $($_.Exception.Message)" ([Drawing.Color]::FromArgb(255,140,140))
        }
    }
    $bGo.Add_Click($goRun)
    $lb.Add_DoubleClick($goRun)
    $bOpen.Add_Click({
        try {
            $dl = Join-Path $ToolDir '下载'
            if (-not (Test-Path $dl)) { New-Item -ItemType Directory -Path $dl -Force | Out-Null }
            Start-Process explorer.exe -ArgumentList ("`"$dl`"")
        } catch {
            Write-Log "[界面] 打开下载目录出错: $($_.Exception.Message)" ([Drawing.Color]::FromArgb(255,140,140))
        }
    })
    [void]$dlg.ShowDialog()
}

# ---- 更新探测: 后台进程 + 定时器读结果(不阻塞 UI) ----
$script:UpdProc = $null
$script:UpdFile = Join-Path $env:TEMP 'sfk_gui_upd.txt'
$timerUpd = New-Object Windows.Forms.Timer
$timerUpd.Interval = 1000
$timerUpd.Add_Tick({
    if ($script:UpdProc -and $script:UpdProc.HasExited) {
        $timerUpd.Stop()
        $line = $null
        if (Test-Path $script:UpdFile) {
            $line = Get-Content -LiteralPath $script:UpdFile -Encoding Default |
                Where-Object { $_ -like 'BGRESULT=*' } | Select-Object -First 1
        }
        if (-not $line) {
            $lblUpd.Text = '更新状态：离线（网络不可达）'
            return
        }
        $v = ($line -split '=', 2)[1]
        if ($v -eq 'OK') {
            $lblUpd.Text = "更新状态：已是最新 v$Ver"
            $lblUpd.ForeColor = [Drawing.Color]::FromArgb(63,214,143)
        } elseif ($v -like 'NEW *') {
            $nv = $v.Substring(4)
            $lblUpd.Text = "更新状态：发现新版本 v$nv，请使用功能 8 更新"
            $lblUpd.ForeColor = [Drawing.Color]::FromArgb(255,92,108)
            Write-Log "云端发现新版本 v$nv — 银狐变种更新很快，新版带有新的黑白名单和检测规则，建议尽快更新。" ([Drawing.Color]::FromArgb(255,92,108))
        } else {
            $lblUpd.Text = '更新状态：离线（网络不可达）'
        }
    }
})
function GUI-StartUpdateProbe {
    $lblUpd.Text = '更新状态：检测中…'
    Remove-Item $script:UpdFile -Force -ErrorAction SilentlyContinue
    $psi = New-Object Diagnostics.ProcessStartInfo
    $psi.FileName = "$env:SystemRoot\System32\cmd.exe"
    $psi.Arguments = "/c call `"$ToolDir\YinHuFix_SelfUpdate.bat`" BGPROBE >`"$script:UpdFile`" 2>&1"
    $psi.WorkingDirectory = $ToolDir
    $psi.UseShellExecute = $false
    $psi.CreateNoWindow = $true
    $script:UpdProc = [Diagnostics.Process]::Start($psi)
    $timerUpd.Start()
}

# ---- 退出确认: 有进程运行时提示 ----
$form.Add_FormClosing({
    if ($script:RunProc -and -not $script:RunProc.HasExited) {
        $r = GUI-MsgBox '确认退出' '功能正在运行，确定退出吗？（后台进程将继续执行至完成）' @('取消','退出') $C.Warn
        if ($r -ne '退出') { $_.Cancel = $true }
    }
})

Write-Log "银狐病毒综合修复工具 GUI v$Ver 已启动（管理员权限）。单击左侧功能查看说明，双击运行。" ([Drawing.Color]::FromArgb(63,214,143))
$form.Add_Shown({ GUI-StartUpdateProbe })
[void]$form.ShowDialog()
